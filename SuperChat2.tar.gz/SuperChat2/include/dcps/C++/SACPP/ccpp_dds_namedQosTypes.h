#ifndef CCPP_DDS_NAMEDQOSTYPES_H
#define CCPP_DDS_NAMEDQOSTYPES_H

#include "ccpp.h"
#include "dds_namedQosTypes.h"
#include "dds_namedQosTypesDcps.h"
#include <orb_abstraction.h>
#include "dds_namedQosTypesDcps_impl.h"

#endif /* CCPP_DDS_NAMEDQOSTYPES_H */
