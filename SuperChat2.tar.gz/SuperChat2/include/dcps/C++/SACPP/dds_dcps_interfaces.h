#ifndef SACPP_DDS_DCPS_INTERFACES_H
#define SACPP_DDS_DCPS_INTERFACES_H

// Nothing much to see here. Just to get the API right for generated code.

#include "dds_dcps.h"

#endif /* SACPP_DDS_DCPS_INTERFACES_H  */
