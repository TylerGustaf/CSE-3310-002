
using test.sacs;

/**
 * 
 * 
 * @date May 04, 2012 
 */
namespace test
{    
	public class SAJTesterSampleInfo {
	    public static void Main(string[] args)
	    {
	        SampleInfo1 sampleInfoTest = new SampleInfo1();
	        sampleInfoTest.runAll();
	    }
	}
}
