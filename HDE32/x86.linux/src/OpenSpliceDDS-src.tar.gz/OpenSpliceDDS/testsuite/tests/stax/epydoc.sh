# generate / update the epydoc python documentation



epydoc -v -o ../docs/epydocs --name test_ospl --css white --url http://www.opensplice.org --dotpath /cygdrive/c/Program\ Files/Graphviz2.26.3/bin/  --inheritance listed --graph all test_ospl


