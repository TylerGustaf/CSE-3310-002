This test is for Coflight test requirement DDS_8 of OpenSplice Coflight req. eFDPfi_MW_DDS_8 - multi node performance

Configuration
-------------

    * DurabilityService \Network\Alignment and set attributeTimeAlignment to true
    * DurabilityService \NetWork\Alignment\RequestCombinePeriod and set both of the attributes Initial and Operational to the value of 5.0
    * DurabilityService \Persistent\StoreMode\ = MMF 



